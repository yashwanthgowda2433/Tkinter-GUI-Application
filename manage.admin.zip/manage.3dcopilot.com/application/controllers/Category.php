<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class Category extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
		if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
	}

	public function browse(){
		
			$page=$this->input->get("page");
			
			if(!$page){
					
				$page=0;
			}
			
			$page_size=25;
			
			if($this->input->get("page_size")>0){
				$page_size=$this->input->get("page_size");
			}
			
			$page_start=$page_size*$page;

			//load category model
			$this->load->model("category_model");
			
			$result=$this->category_model->get_records($page_start,$page_size);
			
			$data['categories']=$result['records'];
			$data['total']=$result['total_records'];
			$data['page_size']=$page_size;
			$data['current_page']=$page+1;
			$data['total_pages']=$data['total']/$page_size;
			$data['total_pages']=$data['total_pages']<1?1:$data['total_pages'];
			
			if($data['total_pages']>(int)($data['total_pages'])){
				$data['total_pages']=(int)($data['total_pages'])+1;
			}
			
			$data['next_page']=false;
			$data['next_page_num']=$page+1;
			$data['prev_page']=true;
			$data['prev_page_num']=$page-1;
			
			if($data['total']>(($page+1) * $page_size)){
				$data['next_page']=true;
			}
			
			if($page==0){
				$data['prev_page']=false;
			}
			
			$data['models']=$this->category_model->get_models();
			$this->lib->render_view("modules/category/browse.php",$data);

    }
    
    
    
    public function create(){
		
			//load  models
			$this->load->model("category_model");

			$this->load->library("form_validation");
			
			
			$this->form_validation->set_rules("model_id","Model", "required");
			$this->form_validation->set_rules("Categories_name","Category name", "required");
			
			if($this->form_validation->run()){
				
				$this->category_model->create();
				
				$this->lib->set_status("New Category added successfully");
				
				redirect("category/browse");

			} else { 
				
				$data['models']=$this->category_model->get_models();
				$this->lib->render_view("modules/category/create.php",$data);
			
			}
			

    }
    
    public function edit($cat_id){
		
			//load  models
			$this->load->model("category_model");

			$this->load->library("form_validation");
			
			
			$this->form_validation->set_rules("model_id","Model", "required");
			$this->form_validation->set_rules("Categories_name","Category name", "required");
			$this->form_validation->set_rules("icons","icons", "required");

			
			
			if($this->form_validation->run()){
				
				$this->category_model->update();
				
				$this->lib->set_status("Category details have been updated!");
				
				redirect("category/browse");

			} else { 
				
				
				$data['category']=$this->category_model->fetch_category($cat_id);
				$data['models']=$this->category_model->get_models();

				$this->lib->render_view("modules/category/edit.php",$data);
			
			}
			

    }
    
     public function fetch_category_by_model(){
		
		//load  models
			$this->load->model("category_model");
		
		$model_id=$this->input->get_post("model_id");
		$selected_category=$this->input->get_post("selected_category");
		
		$categories=$this->category_model->fetch_category_by_model($model_id);
		
		?><option value=''>Select Category</option><?php
		
		foreach($categories as $c):
			?>
				<option value="<?php echo $c['Categories_id']; ?>" <?php if($selected_category==$c['Categories_id']): ?>selected='selected'<?php endif; ?>><?php echo $c['Categories_name']; ?></option>
			<?php
		endforeach;
    
	}
	

	public function mydelete()
    {
        $row_id = $this->input->post('partner_id');
        print_r($row_id);
        $this->db->delete("models_categories",array("Categories_id"=>$row_id));
    }


}
