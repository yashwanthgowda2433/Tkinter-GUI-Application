<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class Comment extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
		if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
	}

	public function browse(){
		
			$page=$this->input->get("page");
			
			if(!$page){
					
				$page=0;
			}
			
			$page_size=25;
			
			$page_start=$page_size*$page;

			//load models
			$this->load->model("comment_model");
			
			$result=$this->comment_model->get_records($page_start,$page_size);
		
			$data['page_size']=$page_size;
			$data['current_page']=$page+1;
			$data['comments']=$result['records'];
			$data['total']=$result['total_records'];
			$data['total_pages']=$data['total']/$page_size;
			$data['total_pages']=$data['total_pages']<1?1:$data['total_pages'];
			
			$data['next_page']=false;
			$data['next_page_num']=$page+1;
			$data['prev_page']=true;
			$data['prev_page_num']=$page-1;
			
			if($data['total']>(($page+1) * $page_size)){
				$data['next_page']=true;
			}
			
			if($page==0){
				$data['prev_page']=false;
			}

			$this->lib->render_view("modules/comments/browse.php",$data);

    }

    
    public function edit($id){
		
			//load  models
			$this->load->model("comment_model");

			$this->load->library("form_validation");
			
			
			$this->form_validation->set_rules("comment","Comment", "required");
			
			if($this->form_validation->run()){
				
				$this->comment_model->update();
				
				$this->lib->set_status("Comment record details have been updated!");
				
				redirect("comment/browse");

			} else { 
				
				
				$data['comment']=$this->comment_model->fetch_record($id);

				$this->lib->render_view("modules/comments/edit.php",$data);
			
			}
			

	}
	
	public function mydelete()
    {
        $row_id = $this->input->post('partner_id');
        print_r($row_id);
        $this->db->delete("comments_table",array("Comment_id"=>$row_id));
    }


}
