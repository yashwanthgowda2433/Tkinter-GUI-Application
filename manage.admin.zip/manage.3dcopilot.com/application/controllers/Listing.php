<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class Listing extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
		if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
	}

	public function browse(){
		
			$page=$this->input->get("page");
			
			if(!$page){
					
				$page=0;
			}
			
			$page_size=25;
			
			if($this->input->get("page_size")>0){
				$page_size=$this->input->get("page_size");
			}
			
			$page_start=$page_size*$page;

			//load category model
			$this->load->model("listing_model");
			
			$result=$this->listing_model->get_records($page_start,$page_size);
			
			$data['listings']=$result['records'];
			$data['total']=$result['total_records'];
			$data['page_size']=$page_size;
			$data['current_page']=$page+1;
			$data['total_pages']=$data['total']/$page_size;
			$data['total_pages']=$data['total_pages']<1?1:$data['total_pages'];
			
			if($data['total_pages']>(int)($data['total_pages'])){
				$data['total_pages']=(int)($data['total_pages'])+1;
			}
			
			$data['next_page']=false;
			$data['next_page_num']=$page+1;
			$data['prev_page']=true;
			$data['prev_page_num']=$page-1;
			
			if($data['total']>(($page+1) * $page_size)){
				$data['next_page']=true;
			}
			
			if($page==0){
				$data['prev_page']=false;
			}
			
			$this->load->model("category_model");
			$data['models']=$this->category_model->get_models();
			
			$this->lib->render_view("modules/listing/browse.php",$data);

    }
    
    public function edit($listing_id){
		
			//load  models
			$this->load->model("listing_model");
			$this->load->model("category_model");

			$this->load->library("form_validation");
			
	
			$this->form_validation->set_rules("Model_id","Model", "required");
			$this->form_validation->set_rules("Categories_id","Category", "required");
			$this->form_validation->set_rules("Model_type","Visibility", "required");
			$this->form_validation->set_rules("check","Status", "required");
			$this->form_validation->set_rules("Tag_name","Tags", "required");
			$this->form_validation->set_rules("Model_name","Listing Name", "required");
			$this->form_validation->set_rules("Model_Description","Description", "required");
			
			
			if($this->form_validation->run()){
				
				$this->listing_model->update();
				
				$this->lib->set_status("Listing details have been updated!");
				
				redirect("listing/browse");

			} else { 
				
				
				$data['listing']=$this->listing_model->fetch_record($listing_id);
				$data['categories']=$this->category_model->fetch_category_by_model($data['listing']['Model_id']);
				$data['models']=$this->category_model->get_models();

				$this->lib->render_view("modules/listing/edit.php",$data);
			
			}
			

	}
	
	public function mydelete()
    {
        $row_id = $this->input->post('partner_id');
        print_r($row_id);
        $this->db->delete("upload_table",array("No_of_models"=>$row_id));
    }


}
