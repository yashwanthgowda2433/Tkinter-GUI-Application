<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class Reviews extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
        if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
        
    }

    public function ratings(){

        $this->lib->render_view("modules/ratings/reviews");

    }

    public function manage(){

        $this->lib->render_view("modules/ratings/manage");
    }

    public function formsubmit(){
        $filename = $_FILES['files']['name'];
        $file_tmp = $_FILES['files']['tmp_name'];
        $dir = 'images_logos/';
        $ratings = $this->input->post('rating-input-1');
        $name = $this->input->post('name');
        $position = $this->input->post('position');
        $services = $this->input->post('services');
        $comments = $this->input->post('comments');
        
        // $location = $dir.''.$path;
        // $imagepath = $path.'/'.$filename;
        
        
        if (move_uploaded_file($file_tmp, $dir.$filename)) {
            $location = base_url($dir.''.$filename);
            $data = array(
                'Rating' => $ratings,
                'Path' => $location,
                'Name' => $name,
                'Position' => $position,
                'Services' => $services,
                'Comments' => $comments
            );
            if($this->db->insert('ratings', $data))
            {
                $valid = "uploaded Successfully!";
                $this->session->set_flashdata('validate_review', $valid);
                redirect(site_url("reviews/ratings"));
            }
            else{
                $valid = "upload fail!";
                $this->session->set_flashdata('validate_review', $valid);
                redirect(site_url("reviews/ratings"));
            }
        }else{
            echo 'failed';
        }
    }

    public function update()
    {
        $filename = $_FILES['files']['name'];
        $file_tmp = $_FILES['files']['tmp_name'];
        $dir = 'images_logos/';
        $id = $this->input->post('id');
        $ratings = $this->input->post('ratings');
        $name = $this->input->post('name');
        $position = $this->input->post('position');
        $services = $this->input->post('services');
        $comments = $this->input->post('comments');
        if (move_uploaded_file($file_tmp, $dir.$filename)) {
            $location = base_url($dir.''.$filename);
            $data = array(
                'Rating' => $ratings,
                'Path' => $location,
                'Name' => $name,
                'Position' => $position,
                'Services' => $services,
                'Comments' => $comments
            );
            $this->db->set($data);
		    $this->db->where('Rate_id', $id);
            $this->db->update('ratings');
            redirect(site_url("reviews/manage"));
        }else{
            $data = array(
                'Rating' => $ratings,
                'Name' => $name,
                'Position' => $position,
                'Services' => $services,
                'Comments' => $comments
            );
            $this->db->set($data);
		    $this->db->where('Rate_id', $id);
            $this->db->update('ratings');
            redirect(site_url("reviews/manage"));

        }
    }

    public function edit(){
        $id = $this->input->post('rate_id');
        // print_r($id);die;
        //load  models
        $this->load->model("Ratings_model");

        $this->load->library("form_validation");
        
            
            $data['ratings']=$this->Ratings_model->fetch_record($id);

            $this->lib->render_view("modules/ratings/edit.php",$data);
        
        
        
}

    public function mydelete()
    {
        $row_id = $this->input->post('partner_id');
        print_r($row_id);
        $this->db->delete("ratings",array("Rate_id"=>$row_id));
    }


}