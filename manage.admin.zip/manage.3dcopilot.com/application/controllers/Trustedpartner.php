<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class Trustedpartner extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
        if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
        
    }

    public function partner(){

        $this->lib->render_view("modules/trusted_partners/partners");

    }

    public function edit(){

        $this->lib->render_view("modules/trusted_partners/edit");

    }

    public function formsubmit(){
        $filename = $_FILES['files']['name'];
        $file_tmp = $_FILES['files']['tmp_name'];
        $dir = 'trustedpartners/';
        $alt = $this->input->post('alt');
        
        // $location = $dir.''.$path;
        // $imagepath = $path.'/'.$filename;
        
        if (move_uploaded_file($file_tmp, $dir.$filename)) {
            $location = base_url($dir.''.$filename);
            $data = array(
                'path' => $location,
                'alt' => $alt
            );
            if($this->db->insert('partners', $data))
            {
                $valid = "uploaded Successfully!";
                $this->session->set_flashdata('valid', $valid);
                redirect(site_url("trustedpartner/partner"));
            }
            else{
                $valid = "upload fail!";
                $this->session->set_flashdata('valid', $valid);
                redirect(site_url("trustedpartner/partner"));
            }
        }else{
            echo 'failed';
        }
    }

    public function mydelete()
    {
        $row_id = $this->input->post('partner_id');
        print_r($row_id);
        $this->db->delete("partners",array("partner_id"=>$row_id));
    }
}