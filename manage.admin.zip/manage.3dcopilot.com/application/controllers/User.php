<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// This can be removed if you use __autoload() in config.php OR use Modular Extensions


class User extends CI_Controller {

	public function __construct()
	{
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

		parent::__construct();

		$this->db->query("SET time_zone='+5:30'");
		
		//check if loggedin
		if(!$this->session->userdata("admin_id")){ redirect("login/validate"); }
	}

	public function browse(){
		
			$page=$this->input->get("page");
			
			if(!$page){
					
				$page=0;
			}
			
			$page_size=25;
			
			if($this->input->get("page_size")>0){
				$page_size=$this->input->get("page_size");
			}
			
			$page_start=$page_size*$page;

			//load category model
			$this->load->model("user_model");
			
			$result=$this->user_model->get_users($page_start,$page_size);
			
			$data['users']=$result['records'];
			$data['total']=$result['total_records'];
			$data['page_size']=$page_size;
			$data['current_page']=$page+1;
			$data['total_pages']=$data['total']/$page_size;
			$data['total_pages']=$data['total_pages']<1?1:$data['total_pages'];
			
			if($data['total_pages']>(int)($data['total_pages'])){
				$data['total_pages']=(int)($data['total_pages'])+1;
			}
			
			$data['next_page']=false;
			$data['next_page_num']=$page+1;
			$data['prev_page']=true;
			$data['prev_page_num']=$page-1;
			
			if($data['total']>(($page+1) * $page_size)){
				$data['next_page']=true;
			}
			
			if($page==0){
				$data['prev_page']=false;
			}
			

			$this->lib->render_view("modules/user/browse.php",$data);

    }
    
    public function edit($user_id){
		
			$this->load->model("user_model");

			$this->load->library("form_validation");
			
			
			$this->form_validation->set_rules("First_name","First Name", "required");
			$this->form_validation->set_rules("Last_name","Last Name", "required");
			$this->form_validation->set_rules("User_name","Username", "required");
			$this->form_validation->set_rules("User_email","Email", "required");
			$this->form_validation->set_rules("Mobile_number","Mobile", "required");
			$this->form_validation->set_rules("Status","Record Status", "required");
			
			if($this->form_validation->run()){
				
				$this->user_model->update();
				
				$this->lib->set_status("User details have been updated!");
				
				redirect("user/browse");

			} else { 
				
				
				$data['user']=$this->user_model->fetch_user($user_id);

				$this->lib->render_view("modules/user/edit.php",$data);
			
			}
			

    }
	
	

}
