<?php
    class Category_model extends CI_Model{

    	public function __construct()
		  {
			$this->load->database();
		  }

      /*
      * @author akshay@neutreum.com
      * @description to retrive a category by cat_id
      */
      public function fetch_category($cat_id){


        $query=$this->db->query("select * from models_categories where Categories_id=?", array($cat_id));
        $result=$query->row_array();

        return $result;

      }
      
      /*
      * @author akshay@neutreum.com
      * @description to retrive a category by model_id
      */
      public function fetch_category_by_model($model_id){


        $query=$this->db->query("select * from models_categories where model_id=?", array($model_id));
        $result=$query->result_array();

        return $result;

      }
      
      //to fetch all models
      public function get_models(){
		  
		$query=$this->db->query("select * from models");
		$result=$query->result_array();  
		
		return $result;
	  }
	  


      /*
      * @author akshay@neutreum.com
      * @description to get all categories records
      */
      public function get_records($page_start,$page_size){
		  
		 $where="";
		
		$count_params=array();
		$params=array();
		
		if($this->input->get_post("model_id")>0){
			
			$model_id=$this->input->get("model_id");
			
			$where.=" and model_id=?";
			
			array_push($count_params,$model_id);
			array_push($params,$model_id);
		 }
		 
		 if($this->input->get_post("search")){
			
			$search=$this->input->get("search");
			
			$where.=" and Categories_name like ?";
			
			array_push($count_params,"%".$search."%");
			array_push($params,"%".$search."%");
		 }
		 
		 
		 $sort_query="";
		 
		 //add page start and page size
		 array_push($params,$page_start, (int)$page_size);

        //count total 
        $count_query=$this->db->query("select count(Categories_id) as total_records from models_categories where 1 ".$where, $count_params);
        $count_results=$count_query->row_array();
        
        //build query
        $query=$this->db->query("select *, (select model_name from models where model_id=mc.model_id limit 1) as model_name from models_categories mc where 1 ".$where.$sort_query." limit ?,?",$params);
        $results=$query->result_array();

        $data['records']=$results;
		$data['total_records']=$count_results['total_records'];

        return $data;

      }
      
     
     /**
       * @author akshay@neutreum.com
       * @description to create a category
       * */
       public function create(){
		   
		  $values=array(
				"model_id"=>$this->input->post("model_id"),
				"Categories_name"=>$this->input->post("Categories_name")
				); 
				
		   $this->db->insert("models_categories", $values);
		   
		   
		   return true;
		  
	   }
	   
	   /**
       * @author akshay@neutreum.com
       * @description to update a category
       * */
       public function update(){
		   
      $Categories_id=$this->input->post("Categories_id"); 
		  
		   
		  $values=array(
				"model_id"=>$this->input->post("model_id"),
        "Categories_name"=>$this->input->post("Categories_name"),
        "icons"=>$this->input->post("icons")
				); 
				
		   $this->db->update("models_categories", $values, array("Categories_id"=>$Categories_id));
		   
		   
		   return true;
		  
	   }
	   
}
