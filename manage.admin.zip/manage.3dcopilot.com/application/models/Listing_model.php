<?php
    class Listing_model extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}

      /*
      * @author akshay@neutreum.com
      * @description to retrive a record by id
      */
      public function fetch_record($record_id){


        $query=$this->db->query("select * from upload_table where No_of_models=?", array($record_id));
        $result=$query->row_array();

        return $result;

      }
	  


      /*
      * @author akshay@neutreum.com
      * @description to get all records
      */
      public function get_records($page_start,$page_size){
		  
		 $where="";
		
		$count_params=array();
		$params=array();
		
		if($this->input->get_post("model_id")>0){
			
			$model_id=$this->input->get("model_id");
			
			$where.=" and model_id=?";
			
			array_push($count_params,$model_id);
			array_push($params,$model_id);
		 }
		 
		 if($this->input->get_post("Categories_id")>0){
			
			$Categories_id=$this->input->get("Categories_id");
			
			$where.=" and (Categories_id=? or Categories_id2=?)";
			
			array_push($count_params,$Categories_id,$Categories_id);
			array_push($params,$Categories_id,$Categories_id);
		 }
		 
		 if($this->input->get_post("search")){
			
			$search=$this->input->get("search");
			
			$where.=" and (Model_name like ? or Model_description like ? or Tag_name like ?)";
			
			array_push($count_params,"%".$search."%","%".$search."%","%".$search."%");
			array_push($params,"%".$search."%","%".$search."%","%".$search."%");
		 }
		 
		 
		 $sort_query="";
		 
		 //add page start and page size
		 array_push($params,$page_start, (int)$page_size);

        //count total 
        $count_query=$this->db->query("select count(No_of_models) as total_records from upload_table where 1 ".$where, $count_params);
        $count_results=$count_query->row_array();
        
        //build query
        $query=$this->db->query("select *, (select model_name from models where model_id=ut.model_id limit 1) as model_id_name,(select concat(First_name,' ',Last_name) from user_module where User_id=ut.User_id limit 1) as user_name, (select Categories_name from models_categories where Categories_id=ut.Categories_id limit 1) as primary_category, (select Categories_name from models_categories where Categories_id=ut.Categories_id2 limit 1) as secondary_category from upload_table ut where 1 ".$where.$sort_query." limit ?,?",$params);
        $results=$query->result_array();

        $data['records']=$results;
		$data['total_records']=$count_results['total_records'];

        return $data;

      }
      
	   
	   /**
       * @author akshay@neutreum.com
       * @description to update a listing
       * */
       public function update(){
		   
		  $No_of_models=$this->input->post("No_of_models"); 


		  if($this->input->post("check") == 'on'){
			  // message
			  $modeldata = $this->db->query("select * from upload_table where No_of_models='".$No_of_models."'")->row();
	$userdata = $this->db->query("select * from user_module where User_id='".$modeldata->User_id."'")->row();
		
	$message = 'Hi '.$this->input->post('user_name').',

	<h5 style="margin-top:15px;font-size:15px;">Congratulations!</h5>
	<p style="margin-top:10px;font-size:14px;">Your asset is published. Now you can showcase your skills and monetize your talent.
	</p>

	<h1 style="color:#666;font-size:17px;margin-top:50px;">Thanks for using 3Dcopilot!</h1>
   <div style="display:flex;border:1px solid transparent;width:max-content;"><img src='.base_url('resources/icons/tabicon.jpg').' style="width:100px;"></div>';
   


   $config=array(
	   'charset'=>'utf-8',
	   'wordwrap'=> TRUE,
	   'mailtype' => 'html'
	   );

   //Load email library 
   $this->load->library('email'); 

   $this->email->initialize($config);
   $this->email->from('support@3dcopilot.com', '3Dcopilot'); 
   $this->email->to($userdata->User_email);
	$this->email->subject('Congratulations!'); 
   
	$this->email->message($message); 
   //  $this->email->attach(base_url('resources/icons/tabicon.jpg'), 'inline');
	//send mail
	$this->email->send();

	// message

		  }



		  if($this->input->post("check") == 'off'){
			// message
			$modeldata = $this->db->query("select * from upload_table where No_of_models='".$No_of_models."'")->row();
  $userdata = $this->db->query("select * from user_module where User_id='".$modeldata->User_id."'")->row();
	  
  $message = 'Hi '.$this->input->post('user_name').',

  <h5 style="margin-top:15px;font-size:15px;">Oops!</h5>
  <p style="margin-top:10px;font-size:14px;">In review process, 3Dcopilot is not published your asset as the content is not undergoes with our guidelines. 
  Please follow the guidelines for your information.
  </p>

  <h1 style="color:#666;font-size:17px;margin-top:50px;">Thanks for using 3Dcopilot!</h1>
 <div style="display:flex;border:1px solid transparent;width:max-content;"><img src='.base_url('resources/icons/tabicon.jpg').' style="width:100px;"></div>';
 


 $config=array(
	 'charset'=>'utf-8',
	 'wordwrap'=> TRUE,
	 'mailtype' => 'html'
	 );

 //Load email library 
 $this->load->library('email'); 

 $this->email->initialize($config);
 $this->email->from('support@3dcopilot.com', '3Dcopilot'); 
 $this->email->to($userdata->User_email);
  $this->email->subject('Disapproved!'); 
 
  $this->email->message($message); 
 //  $this->email->attach(base_url('resources/icons/tabicon.jpg'), 'inline');
  //send mail
  $this->email->send();

  // message

		}
		   
		  $values=array(
				"Model_id"=>$this->input->post("Model_id"),
				"Categories_id"=>$this->input->post("Categories_id"),
				"Categories_id2"=>$this->input->post("Categories_id2"),
				"Model_type"=>$this->input->post("Model_type"),
				"check"=>$this->input->post("check"),
				"Tag_name"=>$this->input->post("Tag_name"),
				"Model_name"=>$this->input->post("Model_name"),
				"Model_Description"=>$this->input->post("Model_Description")
				); 
				
		   $this->db->update("upload_table", $values, array("No_of_models"=>$No_of_models));
		   
		   
		   return true;
		  
	   }
	   
}
