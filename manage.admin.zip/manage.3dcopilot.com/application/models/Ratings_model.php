<?php
    class Ratings_model extends CI_Model{

    	public function __construct()
		{
			$this->load->database();
		}

      /*
      * @author akshay@neutreum.com
      * @description to retrive a comment by id
      */
      public function fetch_record($id){

        $this->db->select('*');
        $this->db->from('ratings');
        $this->db->where('Rate_id',$id);
        $query = $this->db->get();

        return $query->row();

      }
	
	

      /*
      * @author akshay@neutreum.com
      * @description to get all comment records page
      */
      public function get_records($page_start,$page_size){
        
        //count total 
        $count_query=$this->db->query("select count(Comment_id) as total_records from comments_table");
        $count_results=$count_query->row_array();
        
        //retrieve page
        $query=$this->db->query("select ct.*, (select concat(First_name,' ', Last_name) from user_module where User_id=ct.User_id limit 1) as user_name, (select Model_name from upload_table where No_of_models=ct.Model_id limit 1) as model_name from comments_table ct limit ?,?",array($page_start, $page_size));
        $results=$query->result_array();

		$data['records']=$results;
		$data['total_records']=$count_results['total_records'];

        return $data;

      }
      
      
	   /**
       * @author akshay@neutreum.com
       * @description to update a comment record
       * */
       public function update(){
		   
		  $id=$this->input->post("id"); 
		   
		   $values=array(
				
				"Feed_back"=>$this->input->post("comment")
				); 
			
				
		   $this->db->update("comments_table", $values, array("Comment_id"=>$id));
		   
		   return true;
		  
	   }

}
