<?php
    class User_model extends CI_Model{

    	public function __construct()
		  {
			$this->load->database();
		  }

      /*
      * @author akshay@neutreum.com
      * @description to retrive a user by user_id
      */
      public function fetch_user($user_id){


        $query=$this->db->query("select * from user_module where User_id=?", array($user_id));
        $result=$query->row_array();

        return $result;

      }


      /*
      * @author akshay@neutreum.com
      * @description to get all user records
      */
      public function get_users($page_start,$page_size){
		  
		 $where="";
		
		$count_params=array();
		$params=array();
		
		if($this->input->get_post("user_id")>0){
			
			$user_id=$this->input->get("user_id");
			
			$where.=" and u.User_id=?";
			
			array_push($count_params,$user_id);
			array_push($params,$user_id);
		 }
		 
		 if($this->input->get_post("firstname")){
			
			$firstname=$this->input->get("firstname");
			
			$where.=" and u.First_name=?";
			
			array_push($count_params,$firstname);
			array_push($params,$firstname);
		 }
		 
		  if($this->input->get_post("lastname")){
			
			$lastname=$this->input->get("lastname");
			
			$where.=" and u.Last_name=?";
			
			array_push($count_params,$lastname);
			array_push($params,$lastname);
		 }
		 
		 if($this->input->get_post("parent_email")){
			
			$parent_email=$this->input->get("parent_email");
			
			$where.=" and u.User_email=?";
			
			array_push($count_params,$parent_email);
			array_push($params,$parent_email);
		 }
		 
		 if($this->input->get_post("time") and $this->input->get("created_to")){
			
			$created_from=date('Y-m-d',strtotime($this->input->get("created_from")));
			$created_to=date('Y-m-d',strtotime($this->input->get("created_to")));
			
			$where.=" and (date(u.Time) between ? and ?)";
			
			array_push($count_params,$created_from, $created_to);
			array_push($params,$created_from, $created_to);
		 }
		 
		 
		 //sort logic
		 $sort_key=$this->input->get("sort_key",true);
		 $sort_type=$this->input->get("sort_type",true);
		 
		 $sort_query="";
		 
		 $user_fields=array("User_id","First_name","Last_name","User_name","User_email","Time","Status");
		 if(in_array($sort_key,$user_fields) and ($sort_type=="desc" or $sort_type=="asc")){
			
			$sort_query=" order by $sort_key $sort_type";
			
		 }
		 	 
		 //add page start and page size
		 array_push($params,$page_start, (int)$page_size);

        //count total 
        $count_query=$this->db->query("select count(u.User_id) as total_records from user_module u where 1 ".$where, $count_params);
        $count_results=$count_query->row_array();
        
        //build query
        $query=$this->db->query("select u.* from user_module u where 1 ".$where.$sort_query." limit ?,?",$params);
        $results=$query->result_array();

        $data['records']=$results;
		$data['total_records']=$count_results['total_records'];

        return $data;

      }
      
      
     
	   
	   /**
       * @author akshay@neutreum.com
       * @description to update a child profile info
       * */
       public function update(){
		   
		  $user_id=$this->input->post("User_id"); 
		   
		  $values=array(
				"First_name"=>$this->input->post("First_name"),
				"Last_name"=>$this->input->post("Last_name"),
				"User_name"=>$this->input->post("User_name"),
				"User_email"=>$this->input->post("User_email"),
				"Mobile_number"=>$this->input->post("Mobile_number"),
				"Status"=>$this->input->post("Status")
				);  
				
				
				if($this->input->post("Status") == '1'){
					// message
					
		  $userdata = $this->db->query("select * from user_module where User_id='".$user_id."'")->row();
			  
		  $message = 'Hi '.$this->input->post('User_name').',
	  
		  <h5 style="margin-top:15px;font-size:15px;">3Dcopilot approved your seller account. </h5>
		  <p style="margin-top:10px;font-size:14px;">Now you are ready to showcase your skills and monetize your talent.
		  </p>
	  
		  <h1 style="color:#666;font-size:17px;margin-top:50px;">Thanks for using 3Dcopilot!</h1>
		 <div style="display:flex;border:1px solid transparent;width:max-content;"><img src='.base_url('resources/icons/tabicon.jpg').' style="width:100px;"></div>';
		 
	  
	  
		 $config=array(
			 'charset'=>'utf-8',
			 'wordwrap'=> TRUE,
			 'mailtype' => 'html'
			 );
	  
		 //Load email library 
		 $this->load->library('email'); 
	  
		 $this->email->initialize($config);
		 $this->email->from('support@3dcopilot.com', '3Dcopilot'); 
		 $this->email->to($userdata->User_email);
		  $this->email->subject('3Dcopilot Approved! '); 
		 
		  $this->email->message($message); 
		 //  $this->email->attach(base_url('resources/icons/tabicon.jpg'), 'inline');
		  //send mail
		  $this->email->send();
	  
		  // message
	  
				}
	  
	  
	  
				if($this->input->post("Status") == '0'){
					// message
					
		  $userdata = $this->db->query("select * from user_module where User_id='".$user_id."'")->row();
			
		$message = 'Hi '.$this->input->post('user_name').',
	  
		<p style="margin-top:10px;font-size:14px;">In review process, we found that your seller account already associated with us.
		</p>
	  
		<h1 style="color:#666;font-size:17px;margin-top:50px;">Thanks for using 3Dcopilot!</h1>
	   <div style="display:flex;border:1px solid transparent;width:max-content;"><img src='.base_url('resources/icons/tabicon.jpg').' style="width:100px;"></div>';
	   
	  
	  
	   $config=array(
		   'charset'=>'utf-8',
		   'wordwrap'=> TRUE,
		   'mailtype' => 'html'
		   );
	  
	   //Load email library 
	   $this->load->library('email'); 
	  
	   $this->email->initialize($config);
	   $this->email->from('support@3dcopilot.com', '3Dcopilot'); 
	   $this->email->to($userdata->User_email);
		$this->email->subject('Seller Account Already Associated!'); 
	   
		$this->email->message($message); 
	   //  $this->email->attach(base_url('resources/icons/tabicon.jpg'), 'inline');
		//send mail
		$this->email->send();
	  
		// message
	  
			  }
				
		  if($this->input->post("Password")){
			
				$values['Password']=$this->input->post("Password");
			
		  }
				
		   $this->db->update("user_module", $values, array("User_id"=>$user_id));
		   
		   
		   return true;
		  
	   }
	   
}
