<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'>Manage Admins</h1>
	<div class="module-action-items">
		<a href="<?php echo site_url("admin/create"); ?>" class="form-button small-button bg-green">Create Admin</a>
	</div>
	<div class="clear"></div>
</div>

<div class="module-content-section">
	<div class="table-container">
						<table>
						  <tr>
								<th>Admin ID</th>
								<th>Admin Name</th>
								<th>Email</th>
								<th>Status</th>
								<th class="blocks-right">Action</th>
						  </tr>
						  
						  <?php $k=1;
						  foreach($admins as $ad): ?>
						  <tr>
								<td><?php echo $k; ?></td>
								<td><?php echo $ad['admin_name']; ?></td>
								<td><?php echo $ad['email']; ?></td>
								<td>
									<?php if($ad['status']==1): ?>
									<i class="fa fa-play-circle" style=" font-size:1.3em; position:relative; top:2px; color:#9c3;" title='Active'></i>
									<?php else: ?>
									<i class="fa fa-times-circle" style=" font-size:1.3em; position:relative; top:2px; color:#ffa5a5;" title='Inactive'></i>
									<?php endif; ?>
									
								</td>
								<td class="blocks-right">
									<a href="<?php echo site_url("admin/edit/".$ad['admin_id']); ?>" class=""><i class="fas fa-pencil-alt" style=" font-size:1.3em; position:relative; top:2px; color:#ffb800;"></i>Edit</a>
									<a onclick="myDelete(<?php echo $ad['admin_id'];?>)" style="color:red;cursor:pointer;margin-left:10px;">Delete</a>
								
								</td>
						  </tr>
						  <?php $k++;
						endforeach; ?>
						</table>
						
						<div class="data-pagination">
							<?php if($prev_page): ?>
							<a href="<?php echo site_url("admin/browse?page=".$prev_page_num); ?>" class="form-button small-button pagination-buttons">Previous</a>
							<?php endif; ?>
							<?php if($next_page): ?>
							<a href="<?php echo site_url("admin/browse?page=".$next_page_num); ?>" class="form-button small-button pagination-buttons">Next</a>
							<?php endif; ?>
						</div>
</div>

</div>

</div>


<script>
function myDelete(partner_id)
  {
    //    alert(partner_id);
       $.post("<?php echo site_url("admin/mydelete");?>",
       {partner_id:partner_id}, function(data){
           window.location.href="<?php echo site_url("admin/browse"); ?>";
       });
  }
</script>
