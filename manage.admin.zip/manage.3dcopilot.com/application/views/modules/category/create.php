<div class="box-width">
	<div  class="form-container">
		
<div id='create-form'>
<h1 class='h1-title'>Create Category</h1>
<div class="form-div">
	
	<div class="validation-errors"><?php echo validation_errors(); ?></div>
	<form action="<?php echo site_url("category/create"); ?>" method='POST' enctype="multipart/form-data" name="create_form" id="create-form-id">
		
		<div class="form-block">
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Select Model</label>
					<select name="model_id" class="form-select" required>
						<option>Select Model</option>
						<?php foreach($models as $m): ?>
						<option value="<?php echo $m['model_id']; ?>"><?php echo $m['model_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Category Name</label>
					<input type="text" class="form-input" name="Categories_name" placeholder="Category name" value="<?php echo set_value('Categories_name'); ?>" minlength='3' maxlength='50' required/>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row blocks-right">
					<input type="submit" class="form-button bg-green" name="submit" value="Submit" />
					<button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("category/browse"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				<div class="clear"></div>
			</div>
		</div>
	</form>
	<script>
	$("#create-form-id").validate({
		rules: {
			/*repassword: {
				equalTo:'#user-password'
			}*/
		}
	});
	</script>
	</div>
</div>


	</div>
</div>
