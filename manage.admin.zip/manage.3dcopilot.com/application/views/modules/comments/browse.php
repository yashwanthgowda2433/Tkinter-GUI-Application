<div class="module-block">
<div class="module-title-section">
	
	<h2 class="module-title">Manage Comments</h2>
	<div class="module-action-items" style="width:50%;">
		
	</div>
	<div class="clear"></div>
</div>

<?php


parse_str($_SERVER['QUERY_STRING'],$query_array);

$query_array_pagination=$query_array;
$query_array_page_size=$query_array;

$sort_key=$this->input->get("sort_key");
$sort_type=$this->input->get("sort_type");


unset($query_array['sort_key']);
unset($query_array['sort_type']);

$query_string_sort=http_build_query($query_array);

unset($query_array_pagination['page']);

$query_string_pagination=http_build_query($query_array_pagination);

unset($query_array_page_size['page_size']);

$query_string_page_size=http_build_query($query_array_page_size);


if($sort_type=="asc"){

	$sort_type="desc";
	
} else {
	
	$sort_type="asc";
	
	}

?>

<div class="module-content-section">
	<div class="table-header-data">
	   <div class="left">Showing <?php echo $page_size>sizeof($comments)?sizeof($comments):$page_size; ?> of <?php echo $total; ?> | Page <?php echo $current_page; ?> of <?php echo $total_pages; ?></div>
	        <div class="right">
					Records Per Page:  &nbsp; <select name="page_size" class="filter-form-select" style="width:60px;" onchange="window.location.href='<?php echo site_url("comment/browse?".$query_string_page_size); ?>&page_size='+$(this).val()">
						<option <?php if($this->input->get("page_size")==25): ?>selected="selected"<?php endif; ?> value="25">25</option>
						<option <?php if($this->input->get("page_size")==50): ?>selected="selected"<?php endif; ?> value="50">50</option>
						<option <?php if($this->input->get("page_size")==100): ?>selected="selected"<?php endif; ?> value="100">100</option>
						<option <?php if($this->input->get("page_size")==250): ?>selected="selected"<?php endif; ?> value="250">250</option>
					</select>
	         </div>
	    <div class="clear"></div>
	</div>
	<div class="table-container">
						<table>
						  <tr>
								<th>ID</th>
								<th>User</th>
								<th>Model</th>
								<th>Comment</th>
								<th class="blocks-right">Action</th>
						  </tr>
						  
						  <?php $k=1;
						  foreach($comments as $pl): ?>
						  <tr>
								<td><?php echo $k; ?></td>
								<td><?php echo $pl['user_name']; ?></td>
								<td><?php echo $pl['model_name']; ?></td>
								<td><?php echo $pl['Feed_back']; ?></td>
								
								<td class="blocks-right">
									<!-- <a href="<?php echo site_url("comment/edit/".$pl['Comment_id']); ?>" class=""><i class="fas fa-pencil-alt" style=" font-size:1.3em; position:relative; top:2px; color:#ffb800;"></i> Edit</a> -->
									<a onclick="myDelete(<?php echo $pl['Comment_id'];?>)" style="color:red;cursor:pointer;margin-left:10px;">Delete</a>
								</td>
						  </tr>
						  <?php $k++;
						endforeach; ?>
						</table>
						
						<div class="data-pagination">
							<?php if($prev_page): ?>
							<a href="<?php echo site_url("comment/browse?page=".$prev_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Previous</a>
							<?php endif; ?>
							
							<?php
								
								$total=10;
								$start=1;
								
								if($total_pages<=10){
									
									$start=1;
									$total=$total_pages;
								}
								
								if($total_pages==11 and $current_page>=2){ $start=2; $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								if($total_pages==12 and $current_page>=3){ $start=3;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==13 and $current_page>=4){ $start=4;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==14 and $current_page>=5){ $start=5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages>14 and $current_page>5 and $current_page<$total_pages){ $start=$current_page-5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								
								if($total_pages>14 and $current_page==$total_pages){ $start=$current_page-10;  $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								
									
									for($i=$start; $i<=$total; $i++){
										
									if(($i)!=$current_page){
									?>
										<a href="<?php echo site_url("comment/browse?page=".($i-1)."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons"><?php echo $i; ?></a>
									<?php
								 } else {
									 echo "&nbsp;".$i."&nbsp;";
									 }
									
									}
									
									
							
							?>
							
							<?php if($next_page): ?>
							<a href="<?php echo site_url("comment/browse?page=".$next_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Next</a>
							<?php endif; ?>
						</div>
</div>

</div>


</div>


<script>
function myDelete(partner_id)
  {
    //    alert(partner_id);
       $.post("<?php echo site_url("comment/mydelete");?>",
       {partner_id:partner_id}, function(data){
           window.location.href="<?php echo site_url("comment/browse"); ?>";
       });
  }
</script>
