</div>
<footer id="footer">
				<div class="box-width">
					
					<div class="left">
						2019-20 &copy; Peak Prep. All Rights Reserved.
					</div>
					<div class="right">
						<ul class="footer-menu">
							<li><a href="<?php echo site_url("home"); ?>"></a></li>
						</ul>
					</div>
					<div class="clear"></div>
				</div>
			</footer>

</div>
<?php if($status_message=$this->session->userdata("status_message")): ?>
	 <div class="status-message"><?php echo $status_message; ?><div style="text-align:center; padding-top:20px;"><button onclick="hide_status_message();" class="form-button micro-button bg-grey">&nbsp;&nbsp;Ok&nbsp;&nbsp;</button></div></div>
	 <script>
		
		$(document).ready(function(){
			
					show_status_message();
			}); 
		
		
	 </script>
	<?php 
	
	endif;
	
	$this->session->unset_userdata("status_message");
	$this->session->unset_userdata("error_message");
	 
	?>
<div id="black-shade"></div>
<div id="popup">
			<div id="popup-container">
				<div id="popup-contents"></div>
			</div>
			<div id="popup-close" onclick='hide_popup();'><i class="far fa-times-circle"></i></div>
			<div class="clear"></div>
		</div>
<div id="ajax-loader"><img src="<?php echo base_url("images/loader.svg"); ?>" width="100"></div>
</body>
</html>
