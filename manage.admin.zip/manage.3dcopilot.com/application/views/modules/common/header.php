<!DOCTYPE html>
<html>
<head>
<title>3Dcopilot control</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<!-- for title img -->
<link rel="shortcut icon" type="image/icon" href="<?php echo base_url("images/favicon.png"); ?>"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i" rel="stylesheet">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

<link rel="stylesheet" href="<?php echo base_url("css/main.css?v=".time()); ?>" />
<link rel="stylesheet" href="<?php echo base_url("css/responsive.css"); ?>" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <link rel="stylesheet" href="<?php echo base_url("css/jquery.bxslider.css"); ?>">
 <script> var base_url="<?php echo base_url(); ?>"; </script>
<script src="<?php echo base_url("js/lib/jquery-3.3.1.min.js"); ?>" ></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDrJg0RpzxQkcu-WBvZtC_t-IJRlhjSerQ&libraries=geometry,places"></script>
<script src="<?php echo base_url("js/lib/jquery.validate.min.js"); ?>" ></script>
<script src="<?php echo base_url("js/lib/additional-methods.min.js"); ?>" ></script>
<script src="<?php echo base_url("js/main.js"); ?>" ></script>
<script src="https://cdn.tiny.cloud/1/y3up4qnvvapm7nfuzipoi6bwnn7jjgjfao0s3s5dc8yciugj/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script>tinymce.init({selector:'.inline-editor'});</script>
  
  <script>

$( function() {
    
    $(".datepicker").datepicker({
			
      changeMonth: true,
      changeYear: true,
      dateFormat: "dd-mm-yy"
    
		});
     
 });

</script>

</head>
<body>
<div id="container">
			<header id="header">
				<div>
				<div class="header-inner">
					<?php if($this->session->userdata("admin_id") and false): ?>
					<div id="main-menu-cta">
						<i id="main-menu-icon" class="fas fa-grip-horizontal"></i>
					</div>
					<?php endif; ?>
				<div id="header-logo">
					<a href="<?php echo base_url(); ?>" style="font-size:25px; font-weight:bold; color:#555; display:inline-block; padding:5px 0px;">3Dcopilot</a>
				</div>
				
				<div id="header-menu">
					<ul>
						
						<?php if($this->session->userdata("admin_id")): ?>
						<li><i>[ Welcome <?php echo $this->session->userdata("admin_name"); ?> ]</i></li>
						<?php endif; ?>
						
						<li><a href="<?php echo base_url(); ?>">Home</a></li>
						
						<?php if($this->session->userdata("admin_id")): ?>
						<li><a href="<?php echo site_url("login/logout"); ?>">Logout</a></li>
						<?php endif; ?>
						
					</ul>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
				</div>
				</div>
			</header>
			<?php 
				
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				
			
			?>
			<div id="drawer-menu" style="<?php if($class=="login"): echo "display:none;"; endif; ?>">
					<nav id="main-nav">
						<?php if($this->session->userdata("admin_id")): ?>
						
						<a class="main-nav-item<?php if($class=="dashboard"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("dashboard"); ?>">
							<div class="nav-item-icon"><i class="fas fa-list"></i></div>
							<div class="nav-item-label">Dashboard</div>
							<div class="clear"></div>
						</a>						
						<a class="main-nav-item<?php if($class=="admin"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("admin/browse"); ?>">
							<div class="nav-item-icon"><i class="fas fa-user-secret"></i></div>
							<div class="nav-item-label">Moderators</div>
							<div class="clear"></div>
						</a>
						<a class="main-nav-item<?php if($class."/".$method=="user/browse"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("user/browse"); ?>">
							<div class="nav-item-icon"><i class="fas fa-users"></i></div>
							<div class="nav-item-label">Users</div>
							<div class="clear"></div>
						</a>

						<a class="main-nav-item<?php if($class=="models"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("models/model_s"); ?>">
							<div class="nav-item-icon"><i class="fas fa-globe"></i></div>
							<div class="nav-item-label">Models Master</div>
							<div class="clear"></div>
						</a>

						<a class="main-nav-item<?php if($class=="category"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("category/browse"); ?>">
							<div class="nav-item-icon"><i class="fas fa-globe"></i></div>
							<div class="nav-item-label">Category Master</div>
							<div class="clear"></div>
						</a>
						
						<a class="main-nav-item<?php if($class=="listing"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("listing/browse"); ?>">
							<div class="nav-item-icon"><i class="fas fa-file-contract"></i></div>
							<div class="nav-item-label">Manage Content</div>
							<div class="clear"></div>
						</a>
						
						<a class="main-nav-item<?php if($class=="comment"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("comment/browse"); ?>">
							<div class="nav-item-icon"><i class="far fa-comments"></i></div>
							<div class="nav-item-label">Manage Comments</div>
							<div class="clear"></div>
						</a>

						<a class="main-nav-item<?php if($class=="trustedpartner"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("trustedpartner/partner"); ?>">
							<div class="nav-item-icon"><i class="fas fa-user-friends"></i></div>
							<div class="nav-item-label">Trusted Partners</div>
							<div class="clear"></div>
						</a>
						<a class="main-nav-item<?php if($class=="reviews"): echo " active-nav-item"; endif; ?>" href="<?php echo site_url("reviews/ratings"); ?>">
							<div class="nav-item-icon"><i class="fas fa-user-edit"></i></div>
							<div class="nav-item-label">Client Ratings</div>
							<div class="clear"></div>
						</a>

						<?php endif; ?>
					</nav>
			</div>
			<div class="header-top-margin"></div>
			<div id="drawer-spacer"></div>
			<div id="data-container">
