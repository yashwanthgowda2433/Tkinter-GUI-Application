<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'>Listings</h1>
	<div class="module-action-items">
	
		
	</div>
	<div class="clear"></div>
	<div class="mega-filter">
		<form class="browse-filter-form" action="<?php echo site_url("listing/browse"); ?>">
			<div class="filter-form-row">
				
				<div class="form-column">
					<span class="filter-label">Search</span> <input type="text" name="search" class="filter-form-input" placeholder="Category Name" value="<?php echo $this->input->get("search"); ?>" />
				</div>
				<div class="form-column">
					<span class="filter-label">Models</span> 
					<select name="model_id" class="filter-form-select" onchange="load_categories($(this).val());">
						<option value=''>Select</option>
						
						<?php foreach($models as $m): ?>
						<option value="<?php echo $m['model_id']; ?>"><?php echo $m['model_name']; ?></option>
						<?php endforeach; ?>
						
					</select>
					<select class="filter-form-select" name="Categories_id" id="topics-dropdown" style="display:none;" >
					
					</select>
		
				<div class="clear"></div>
			</div>
			
			
			<div>
			 <input type="submit" class="form-button small-button bg-green" value="Apply" /> <a href="<?php echo site_url("listing/browse"); ?>" class="form-button small-button bg-grey">&nbsp;<i class="fas fa-redo"></i> &nbsp; Reset</a>
			 </div>
		</form>
	</div>
</div>

<?php


parse_str($_SERVER['QUERY_STRING'],$query_array);

$query_array_pagination=$query_array;
$query_array_page_size=$query_array;

$sort_key=$this->input->get("sort_key");
$sort_type=$this->input->get("sort_type");


unset($query_array['sort_key']);
unset($query_array['sort_type']);

$query_string_sort=http_build_query($query_array);

unset($query_array_pagination['page']);

$query_string_pagination=http_build_query($query_array_pagination);

unset($query_array_page_size['page_size']);

$query_string_page_size=http_build_query($query_array_page_size);


if($sort_type=="asc"){

	$sort_type="desc";
	
} else {
	
	$sort_type="asc";
	
	}

?>

<div class="module-content-section">
	<div class="table-header-data">
		
	<div class="left">Showing <?php echo $page_size>sizeof($listings)?sizeof($listings):$page_size; ?> of <?php echo $total; ?> | Page <?php echo $current_page; ?> of <?php echo $total_pages; ?></div>
	<div class="right">
					Records Per Page:  &nbsp; <select name="page_size" class="filter-form-select" style="width:60px;" onchange="window.location.href='<?php echo site_url("listing/browse?".$query_string_page_size); ?>&page_size='+$(this).val()">
						<option <?php if($this->input->get("page_size")==25): ?>selected="selected"<?php endif; ?> value="25">25</option>
						<option <?php if($this->input->get("page_size")==50): ?>selected="selected"<?php endif; ?> value="50">50</option>
						<option <?php if($this->input->get("page_size")==100): ?>selected="selected"<?php endif; ?> value="100">100</option>
						<option <?php if($this->input->get("page_size")==250): ?>selected="selected"<?php endif; ?> value="250">250</option>
					</select>
	</div>
	<div class="clear"></div>
	
	</div>
	<div class="table-container">
						<table>
						  <tr>
								<th>Record ID</th>
								<th>Thumbnail</th>
								<th>Listing Name</th>
								<th>Description</th>
								<th>Model Name</th>
								<th>Category</th>
								<th>User</th>
								<th>Model Type</th>
								<th>Tags</th>
								<th>Status</th>
								<th>Check</th>
								<th>Time</th>
								<th>Action</th>
						  </tr>
						  
						  <?php $k=1;
						  foreach($listings as $l): ?>
						  <tr>
								<td><?php echo $l['No_of_models']; ?></td>
								<td>
									
									<?php if($l['Thumbnail']): ?>
									<img src="<?php echo $this->config->item('user_base_url').$l['Thumbnail']; ?>"  style="width:50px;"/> 
									<?php endif; ?>
								
								</td>
								<td><?php echo $l['Model_name']; ?></td>
								<td><?php echo $l['Model_Description']; ?></td>
								<td><?php echo $l['model_id_name']; ?></td>
								<td><?php echo $l['primary_category']; ?>, <?php echo $l['secondary_category']; ?></td>
								<td><?php echo $l['user_name']; ?></td>
								<td><?php echo $l['Model_type']; ?></td>
								<td><?php echo $l['Tag_name']; ?></td>
								<td><?php if($l['Sale_count'] > 0){
									echo '$'.$l['Sale_count'];
								}else{
									echo 'Free';
								} ?></td>

								<td><?php echo $l['check']; ?></td>
								<td><?php echo $l['Time']; ?></td>
								<td>
									<a href="<?php echo site_url("listing/edit/".$l['No_of_models']); ?>" class="" title="Edit Listing"><i class="fas fa-pencil-alt" style=" font-size:1.3em; position:relative; top:2px; color:#ffb800;"></i> Edit</a>
									<a onclick="myDelete(<?php echo $l['No_of_models'];?>)" style="color:red;cursor:pointer;margin-left:10px;">Delete</a>
									
								</td>
						  </tr>
						  
						  <?php endforeach; ?>
						</table>
						<div class="data-pagination">
							<?php if($prev_page): ?>
							<a href="<?php echo site_url("listing/browse?page=".$prev_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Previous</a>
							<?php endif; ?>
							
							<?php
								
								$total=10;
								$start=1;
								
								if($total_pages<=10){
									
									$start=1;
									$total=$total_pages;
								}
								
								if($total_pages==11 and $current_page>=2){ $start=2; $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								if($total_pages==12 and $current_page>=3){ $start=3;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==13 and $current_page>=4){ $start=4;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==14 and $current_page>=5){ $start=5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages>14 and $current_page>5 and $current_page<$total_pages){ $start=$current_page-5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								
								if($total_pages>14 and $current_page==$total_pages){ $start=$current_page-10;  $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								
									
									for($i=$start; $i<=$total; $i++){
										
										if(($i)!=$current_page){
									?>
										<a href="<?php echo site_url("listing/browse?page=".($i-1)."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons"><?php echo $i; ?></a>
									<?php
								 } else {
									 echo "&nbsp;".$i."&nbsp;";
									 }
									
									}
									
									
							
							?>
							
							<?php if($next_page): ?>
							<a href="<?php echo site_url("listing/browse?page=".$next_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Next</a>
							<?php endif; ?>
						</div>
</div>

</div>


</div>

<script>
	
function load_categories(model_id)
{
	
	if(model_id>0){
	
		$.post(base_url+"index.php/category/fetch_category_by_model", {model_id:model_id}, function(data){
			
			$("#topics-dropdown").html(data);
			$("#topics-dropdown").fadeIn();
		
		});
	
	
	}  else {
		$("#topics-dropdown").html("");
		$("#topics-dropdown").fadeOut();
	}
	
}

function confirm_delete(url){
		
		
     var response=confirm("Are you sure you want to delete the Listing?");
     
     if(response==true){
		 
	   window.location.href=url;
	 
	 }
    
 }

</script>


<script>
function myDelete(partner_id)
  {
    //    alert(partner_id);
       $.post("<?php echo site_url("listing/mydelete");?>",
       {partner_id:partner_id}, function(data){
           window.location.href="<?php echo site_url("listing/browse"); ?>";
       });
  }
</script>
 
