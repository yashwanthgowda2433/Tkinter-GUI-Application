<div class="box-width">
	<div  class="form-container">
		
<div id='create-form'>
<h1 class='h1-title'>Edit Listing</h1>
<div class="form-div">
	
	<div class="validation-errors"><?php echo validation_errors(); ?></div>
	<form action="<?php echo site_url("listing/edit/".$listing['No_of_models']); ?>" method='POST' enctype="multipart/form-data" name="create_form" id="create-form-id">
		<input type="hidden" name="No_of_models" value="<?php echo $listing['No_of_models']; ?>" />
		<input type="hidden" name="referred_by" value="<?php echo @$_SERVER['HTTP_REFERER']; ?>" />
		<div class="form-block">
			<div class="form-row">
			
				<div class="form-column">
					<label class="radio-label">Model</label>
					
					<select class="form-select input-small-width" name="Model_id" onchange="load_categories($(this).val(),<?php echo $listing['Categories_id']; ?>,'categories-dropdown'); load_categories($(this).val(),<?php echo $listing['Categories_id2']; ?>,'categories2-dropdown');" required>
						<option>Select Model</option>
						<?php foreach($models as $model): ?>
						<option value="<?php echo $model['model_id']; ?>" <?php if($model['model_id']==$listing['Model_id']): echo "selected='selected'"; endif; ?>><?php echo $model['model_name']; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				
				<div class="form-column">
					<label class="radio-label">Primary Category</label>
					
					<select class="form-select input-small-width" name="Categories_id" id="categories-dropdown" required>
						
					</select>
				</div>
				
				<div class="form-column">
					<label class="radio-label">Secondary Category</label>
					
					<select class="form-select input-small-width" name="Categories_id2" id="categories2-dropdown">
						
					</select>
				</div>
				
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				
				
				
				<div class="form-column">
					<label class="radio-label">Visibility</label>
					<label class="form-radio">
					<input type="radio" name="Model_type" value="Public" <?php echo set_radio('Model_type','Public',$listing['Model_type']=='Public'? true:false); ?> required/> Public
					</label>
					<label class="form-radio">
					<input type="radio" name="Model_type" value="Private" <?php echo set_radio('Model_type','Private',$listing['Model_type']=='Private'? true:false); ?> required/> Private
					</label>
					
					
				</div>
				
				<div class="form-column">
					<label class="radio-label">Status</label>
					<label class="form-radio">
					<input type="radio" name="check" value="on" <?php echo set_radio('check','on',$listing['check']=='on'? true:false); ?> required/> On
					</label>
					<label class="form-radio">
					<input type="radio" name="check" value="off" <?php echo set_radio('check','off',$listing['check']=='off'? true:false); ?> required/> Off
					</label>
				</div>
				
				<div class="form-column" >
					<label class="radio-label">Tags</label>
					<input type="text" class="form-input"  name="Tag_name" placeholder="Tags seperated by comma" value="<?php echo set_value('Tag_name',($listing['Tag_name'])); ?>" required/>
				</div>
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				
				
				<div class="clear"></div>
			</div>
			
			
			<div style="border-top:1px solid #eee; margin:20px 0px;"></div>
			
			<div class="form-row">
				<div class="form-column" style="width:90%;">
					<label class="radio-label">Listing Name</label>
					<input type="text" class="form-input" style="width:100%;" name="Model_name" placeholder="Enter Listing Name" value="<?php echo set_value('Model_name',($listing['Model_name'])); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				
				<div class="form-column" style="width:90%;">
					<label class="radio-label">Description</label>
					<!--  inline-editor -->
					<textarea class="form-input" style="width:100%;" name="Model_Description" placeholder="Enter Description" required><?php echo set_value('Model_Description',($listing['Model_Description'])); ?></textarea>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row">
					<div class="form-column">
						<label class="radio-label">Thumbnail Image</label>
						<!--<input type="file" class="form-input" name="Thumbnail" >-->
						<?php if($listing['Thumbnail']): ?><div class="option-image"><img src="<?php echo $this->config->item('user_base_url').$listing['Thumbnail']; ?>" height="100px" /></div><?php endif; ?>
					</div>
					<div class="clear"></div>
				</div>
			
			
	
			<div class="form-row blocks-right">
					<input type="submit" class="form-button bg-green" name="submit" value="Submit" />
					<button type="button" class="form-button bg-grey" name="submit" onclick="window.history.back();"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				<div class="clear"></div>
			</div>
			
		</div>
	</form>
	<script>
		
		$(document).ready(function(){
			
		load_categories(<?php echo $listing['Model_id']; ?>,<?php echo $listing['Categories_id']; ?>,'categories-dropdown'); 
		<?php if($listing['Categories_id2']){ ?>
		load_categories(<?php echo $listing['Model_id']; ?>,<?php echo $listing['Categories_id2']; ?>,'categories2-dropdown');
		<?php }?>
		
		});
	
	$.validator.addMethod('filesize', function (value, element, param) {
    return this.optional(element) || (element.files[0].size <= param)
}, 'File size must be less than {0} bytes');	
		
	$("#create-form-id").validate({
		rules: {
			file_option_a: {
				accept: "image/*",
				filesize:50000
			},
			file_option_b: {
				accept: "image/*",
				filesize:50000
			},
			file_option_c: {
				accept: "image/*",
				filesize:50000
			},
			file_option_d: {
				accept: "image/*",
				filesize:50000
			},
			file_option_e: {
				accept: "image/*",
				filesize:50000
			},
			question_image: {
				accept: "image/*",
				filesize:100000
			},
			review_image: {
				accept: "image/*",
				filesize:100000
			}
		}, 
		
		message: {
			
			file_option_a: {
				accept: "Only png/jpg/gif allowed"
			},
			file_option_b: {
				accept: "Only png/jpg/gif allowed"
			},
			file_option_c: {
				accept: "Only png/jpg/gif allowed"
			},
			file_option_d: {
				accept: "Only png/jpg/gif allowed"
			},
			file_option_e: {
				accept: "Only png/jpg/gif allowed"
			},
			question_image: {
				accept: "Only png/jpg/gif allowed"
			},
			review_image: {
				accept: "Only png/jpg/gif allowed"
			}
		}
	});
	
	function load_categories(model_id, selected_category, element_id)
	{
		
		if(model_id>0){
		
			$.post(base_url+"index.php/category/fetch_category_by_model", {model_id:model_id, selected_category:selected_category}, function(data){
				
				$("#"+element_id).html(data);
				$("#"+element_id).fadeIn();
			
			});
		
		
		}  else {
			$("#"+element_id).html("");
			$("#"+element_id).fadeOut();
		}
		
	}
	
	</script>
	</div>
</div>


	</div>
</div>
