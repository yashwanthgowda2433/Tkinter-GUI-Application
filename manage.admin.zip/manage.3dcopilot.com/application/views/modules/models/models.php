<?php
$this->db->select('*');
$this->db->from('models');
$query = $this->db->get();

?>

<div class="module-block">
   <div class="module-title-section">
	
	     <h1 class='module-title'>Manage Models</h1>
         <div class="module-action-items">
		     <a href="<?php echo site_url("models/create"); ?>" class="form-button small-button bg-green">Create Model</a>
	     </div>
         <div class="clear"></div>
     </div>
     <div class="module-content-section">
            <div class="table-container">
						<table>
						  <tr>
								<th>ID</th>
								<th>Model Name</th>
								<th>Width</th>
								<th>Height</th>
								
								<th class="blocks-right">Action</th>
						  </tr>
						  
                          <?php if($query)
                        { 
                            $k=1; // print_r($query->result());?>
                          <?php foreach($query->result() as $row){ ?>
						  <tr>
								<td><?php echo $row->model_id; ?></td>
								<td><?php echo $row->model_name; ?></td>
								<td><?php echo $row->width; ?></td>
								<td><?php echo $row->Height; ?></td>
								

								
								<td class="blocks-right">
                                <form action="<?php echo site_url("models/edit"); ?>" method='POST'>
                                 <input type="hidden" name="model_id" value="<?php echo $row->model_id;?>">
									<button type="submit" style="border:none;background:transparent;cursor:pointer;">
                                    <a style="display:flex;"><i class="fas fa-pencil-alt" style=" font-size:1.3em; position:relative; top:2px; color:#ffb800;"></i>&nbsp;Edit</a></button>
                                </form>
									<a onclick="myDelete(<?php echo $row->model_id;?>)" style="color:red;cursor:pointer;">&nbsp;Delete</a>
									
								</td>
						  </tr>
                          <?php $k++; }?>
                          <?php }?>
						</table> 
                </div>

                <div class="form-row blocks-right">
					      
					      <button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("category/browse"); ?>')"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				     <div class="clear"></div>
			    </div>
            
     </div>
</div>

<script>
function myDelete(partner_id)
  {
    //    alert(partner_id);
       $.post("<?php echo site_url("models/mydelete");?>",
       {partner_id:partner_id}, function(data){
           window.location.href="<?php echo site_url("models/model_s"); ?>";
       });
  }
</script>