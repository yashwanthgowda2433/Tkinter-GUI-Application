<style>
.form-row{
    display:flex;
}
</style>
<div class="box-width">
	<div  class="form-container">
		
<div id='edit-form'>
<h1 class='h1-title'>Edit Ratings</h1>
<div class="form-div">
	
	<!-- <div class="validation-errors"><?php echo validation_errors(); ?></div> -->
	<form action="<?php echo site_url("reviews/update"); ?>" method='POST' enctype="multipart/form-data" name="edit_form" id="edit-form-id">
		<input type="hidden" name="id" value="<?php echo $ratings->Rate_id; ?>" />
		<div class="form-block">

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Ratings</label>
					       <input type="text" class="form-input" name="ratings" placeholder="name" value="<?php echo $ratings->Rating;?>" required="">
				       </div>
                    </div>
                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Logo</label>
                           <div class="form-row">
                             <img src="<?php echo $ratings->Path;?>" style="width:150px;">
                           </div>
                           <div class="form-row">
                               <div class="form-column">
                                   <label class="radio-label">Choose File To Change Logo</label>
					               <input type="file" name="files" class="form-input" value="Change Logo">
                                </div>
                           </div>
                        </div>
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Name</label>
					       <input type="text" class="form-input" name="name" placeholder="name" value="<?php echo $ratings->Name; ?>" required="">
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Position</label>
					       <input type="text" class="form-input" name="position" placeholder="Position" value="<?php echo $ratings->Position; ?>" required="">
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column" style="margin-right:0px;">
					       <label class="radio-label">Services</label>
                           <?php
                           if($ratings->Services == '3D Services')
                           {
                           echo '
					       <select class="form-input" name="services" required="" style="width:320px;">
                           <option>3D Services</option>
                           <option>Design Services</option>
                           <option>Video Services</option>
                           <option>Visual Effects(vfx)</option>
                           </select>';
                           }else if($ratings->Services == 'Design Services')
                           {
                           echo '
                           <select class="form-input" name="services" required="" style="width:320px;">
                           <option>Design Services</option>
                           <option>3D Services</option>
                           <option>Video Services</option>
                           <option>Visual Effects(vfx)</option>
                           </select>';
                           }else if($ratings->Services == 'Video Services')
                           {
                           echo '
                           <select class="form-input" name="services" required="" style="width:320px;">
                           <option>Video Services</option>
                           <option>3D Services</option>
                           <option>Design Services</option>
                           <option>Visual Effects(vfx)</option>
                           </select>';
                           }else if($ratings->Services == 'Visual Effects(vfx)')
                           {
                           echo '
                           <select class="form-input" name="services" required="" style="width:320px;">
                           <option>Visual Effects(vfx)</option>
                           <option>3D Services</option>
                           <option>Design Services</option>
                           <option>Video Services</option>
                           </select>';
                           }
                           ?>
				       </div>
                    </div>
			
			
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Comment</label>
					<textarea name='comments' class="form-input"><?php echo set_value('comment',$ratings->Comments);?></textarea>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row blocks-right">
					<input type="submit" class="form-button bg-green" name="submit" value="Save.." />
					<button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("reviews/manage"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				<div class="clear"></div>
			</div>
		</div>
	</form>
	<script>
	$("#edit-form-id").validate({
		rules: {
			/*repassword: {
				equalTo:'#user-password'
			}*/
		}
	});
	</script>
	</div>
</div>


	</div>
</div>
