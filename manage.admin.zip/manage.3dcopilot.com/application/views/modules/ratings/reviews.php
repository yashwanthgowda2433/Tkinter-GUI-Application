<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
<style>
.rating-star{
    margin-left:10px;
}
.blocks-right{
    width: fit-content;
    margin: auto;
}
.form-row{
    display:flex;
    width:100%;
}
textarea{
    resize:none;
}
.fit-form{
    width:fit-content;
    margin:auto;
}
.rating {
    overflow: hidden;
    display: inline-block;
    font-size: 0;
    position: relative;
}
.rating-input {
    float: right;
    width: 16px;
    height: 16px;
    padding: 0;
    margin: 0 0 0 -16px;
    opacity: 0;
}
.rating:hover .rating-star:hover,
.rating:hover .rating-star:hover ~ .rating-star,
.rating-input:checked ~ .rating-star {
    background-position: 0 0;
}
.rating-star,
.rating:hover .rating-star {
    position: relative;
    float: right;
    display: block;
    width: 16px;
    height: 16px;
    background: url('<?php echo site_url('images/star.png');?>') 0 -16px;
}
</style>
<div class="module-block">
   <div class="module-title-section">
	
	     <h1 class='module-title'>Client Ratings</h1>
         <div class="module-action-items">
		     <a href="<?php echo site_url("reviews/manage"); ?>" class="form-button small-button bg-green">Manage</a>
	     </div>
	     
	     <div class="clear"></div>
     </div>
     <div class="module-content-section">
         <form method="POST" enctype="multipart/form-data" action="<?php echo site_url('reviews/formsubmit');?>">
                <div class="fit-form">
                <div class="form-row">
                    <div class="form-column">
                       <label class="radio-label">Ratings</label>
    <span class="rating">
        <input type="radio" class="rating-input" id="rating-input-1-5" name="rating-input-1"/>
        <label for="rating-input-1-5" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-1-4" name="rating-input-1"/>
        <label for="rating-input-1-4" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-1-3" name="rating-input-1"/>
        <label for="rating-input-1-3" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-1-2" name="rating-input-1"/>
        <label for="rating-input-1-2" class="rating-star"></label>
        <input type="radio" class="rating-input" id="rating-input-1-1" name="rating-input-1"/>
        <label for="rating-input-1-1" class="rating-star" style="margin-left:0px;"></label>
	</span>
                    </div>
                </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label class="radio-label">Photo or Logo</label>
                            <input type="file" name="files" class="form-input">
                       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Name</label>
					       <input type="text" class="form-input" name="name" placeholder="name" value="" required="">
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Position</label>
					       <input type="text" class="form-input" name="position" placeholder="Position" value="" required="">
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column" style="margin-right:0px;">
					       <label class="radio-label">Services</label>
					       <select class="form-input" name="services" required="" style="width:320px;">
                           <option label="select"></option>
                           <option>3D Services</option>
                           <option>Design Services</option>
                           <option>Video Services</option>
                           <option>Visual Effects(vfx)</option>
                           </select>
				       </div>
                    </div>

                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Comments</label>
					       <textarea class="form-input" rows="10" name="comments" placeholder="Comments" required=""></textarea>
				       </div>
                    </div>

                    <div class="form-row" style="display:flex;width:100%;">
                       
                           <P style="color:green;"><?php echo $this->session->flashdata('validate_review');?></p>
                        
                    </div>
                    <div class="form-row blocks-right" >
					      <input type="submit" class="form-button bg-green" name="submit" value="Submit">
					      <button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("admin/browse"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				     <div class="clear"></div>
			        </div>
                </div>
          </form>
     </div>
</div>
    
<script>
    $( document ).ready(function() {
	$( "input.rating-input" ).click(function() {
		name=$(this).attr('name');
		$("input[name='"+name+"']").val(""); // remove value from all radio's (with this name)
		$("input[name='"+name+"']:checked").val($(this).attr('id')); // add value to checked radio
	});
});
</script>