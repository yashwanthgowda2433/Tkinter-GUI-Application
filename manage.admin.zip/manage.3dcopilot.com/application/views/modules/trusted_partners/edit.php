<?php
$this->db->select('*');
$this->db->from('partners');
$query = $this->db->get();

?>

<div class="module-block">
   <div class="module-title-section">
	
	     <h1 class='module-title'>Manage Partners</h1>
         <div class="clear"></div>
     </div>
     <div class="module-content-section">
            <div class="table-container">
						<table>
						  <tr>
								<th>ID</th>
								<th>Image Path</th>
								<th>Alt</th>
								<th>Time</th>
								<th class="blocks-right">Action</th>
						  </tr>
						  
                          <?php if($query)
                        { 
							$k=1;
                            // print_r($query->result());?>
                          <?php foreach($query->result() as $row){ ?>
						  <tr>
								<td><?php echo $k; ?></td>
								<td><img src="<?php echo $row->path; ?>" style="width:50px;"></td>
								<td><?php echo $row->alt; ?></td>
								<td><?php echo $row->Time; ?></td>
								
								<td class="blocks-right">
									<a onclick="myDelete(<?php echo $row->partner_id;?>)" style="color:red;cursor:pointer;">Delete</a>
									
								</td>
							
						  </tr>
                          <?php $k++; }?>
                          <?php }?>
						</table>
                </div>

                <div class="form-row blocks-right">
					      
					      <button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("Trustedpartner/partner"); ?>')"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				     <div class="clear"></div>
			    </div>
            
     </div>
</div>



<script>
function myDelete(partner_id)
  {
    //    alert(partner_id);
       $.post("<?php echo site_url("Trustedpartner/mydelete");?>",
       {partner_id:partner_id}, function(data){
           window.location.href="<?php echo site_url("trustedpartner/edit"); ?>";
       });
  }
</script>