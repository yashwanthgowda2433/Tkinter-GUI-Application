<style>
.blocks-right{
    margin-top:100px;
}
</style>
<div class="module-block">
   <div class="module-title-section">
	
	     <h1 class='module-title'>Trusted Partners</h1>
         <div class="module-action-items">
		     <a href="<?php echo site_url("trustedpartner/edit"); ?>" class="form-button small-button bg-green">Manage</a>
	     </div>
	     
	     <div class="clear"></div>
     </div>
     <div class="module-content-section">
         <form method="POST" enctype="multipart/form-data" action="<?php echo site_url('trustedpartner/formsubmit');?>">
                <div>
                    <div class="form-row">
                       <input type="file" name="files" class="form-input">
                    </div>
                    <div class="form-row">
                       <div class="form-column">
					       <label class="radio-label">Alt</label>
					       <input type="text" class="form-input" name="alt" placeholder="Image name" value="" required="">
				       </div>
                    </div>
                    <div class="form-row" style="display:flex;width:100%;">
                       
                           <P style="color:green;"><?php echo $this->session->flashdata('valid');?></p>
                        
                    </div>
                    <div class="form-row blocks-right">
					      <input type="submit" class="form-button bg-green" name="submit" value="Submit">
					      <button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("admin/browse"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				     <div class="clear"></div>
			        </div>
                </div>
          </form>
     </div>
</div>
    