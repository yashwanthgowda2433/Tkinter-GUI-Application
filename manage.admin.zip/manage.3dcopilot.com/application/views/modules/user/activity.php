<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'><?php echo $user['firstname']." ".$user['lastname']; ?></h1>
	<div class="subscription-nav">
		<?php
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				$current_nav=$class."/".$method;
		?>
		<a <?php if($current_nav=="user/view"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/view/".$user['id']); ?>">Profile</a>
		<a <?php if($current_nav=="user/subscriptions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/subscriptions/".$user['id']); ?>">Subscription</a>
		<a <?php if($current_nav=="user/transactions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/transactions/".$user['id']); ?>">Transactions</a>
		<a <?php if($current_nav=="user/activity"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/activity/".$user['id']); ?>">Activity Log</a>
		<a <?php if($current_nav=="user/parent_profile"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/parent_profile/".$user['id']); ?>">Parent Profile</a>
		
	</div>
	<div class="clear"></div>
</div>

<?php


parse_str($_SERVER['QUERY_STRING'],$query_array);

$query_array_pagination=$query_array;
$query_array_page_size=$query_array;

$sort_key=$this->input->get("sort_key");
$sort_type=$this->input->get("sort_type");


unset($query_array['sort_key']);
unset($query_array['sort_type']);

$query_string_sort=http_build_query($query_array);

unset($query_array_pagination['page']);

$query_string_pagination=http_build_query($query_array_pagination);

unset($query_array_page_size['page_size']);

$query_string_page_size=http_build_query($query_array_page_size);


if($sort_type=="asc"){

	$sort_type="desc";
	
} else {
	
	$sort_type="asc";
	
	}

?>

<div class="module-content-section">
	<div class="table-header-data">
		
	<div class="left">Showing <?php echo $page_size; ?> of <?php echo $total; ?> | Page <?php echo $current_page; ?> of <?php echo $total_pages; ?></div>
	<div class="right">
					Records Per Page:  &nbsp; <select name="page_size" class="filter-form-select" style="width:60px;" onchange="window.location.href='<?php echo site_url("user/activity/".$user['id']."?".$query_string_page_size); ?>&page_size='+$(this).val()">
						<option <?php if($this->input->get("page_size")==25): ?>selected="selected"<?php endif; ?> value="25">25</option>
						<option <?php if($this->input->get("page_size")==50): ?>selected="selected"<?php endif; ?> value="50">50</option>
						<option <?php if($this->input->get("page_size")==100): ?>selected="selected"<?php endif; ?> value="100">100</option>
						<option <?php if($this->input->get("page_size")==250): ?>selected="selected"<?php endif; ?> value="250">250</option>
					</select>
	</div>
	<div class="clear"></div>
	
	</div>
	<div class="table-container">
					
		<table>
						  <tr>
								<th>ID</th>
								<th>Activity Type</th>
								<th>IP Address</th>
								<th>Activity Time</th>
								
						  </tr>
						  <?php foreach($activities as $act): ?>
							<tr>
								<td><?php echo $act['id']; ?></td>
								<td><?php echo $act['activity_type']; ?></td>
								<td><?php echo $act['ip_address']; ?></td>
								<td><?php echo $act['created']; ?></td>
									
							</tr>
						  <?php endforeach; ?>
						  </table>
						  
						  <div class="data-pagination">
							<?php if($prev_page): ?>
							<a href="<?php echo site_url("user/activity/".$user['id']."?page=".$prev_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Previous</a>
							<?php endif; ?>
							
							<?php
								
								$total=10;
								$start=1;
								
								if($total_pages<=10){
									
									$start=1;
									$total=$total_pages;
								}
								
								if($total_pages==11 and $current_page>=2){ $start=2; $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								if($total_pages==12 and $current_page>=3){ $start=3;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==13 and $current_page>=4){ $start=4;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages==14 and $current_page>=5){ $start=5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								if($total_pages>14 and $current_page>5 and $current_page<$total_pages){ $start=$current_page-5;  $total=($total+$start)>$total_pages?$total_pages:($total+$start);}
								
								if($total_pages>14 and $current_page==$total_pages){ $start=$current_page-10;  $total=($total+$start)>$total_pages?$total_pages:($total+$start); }
								
									
									for($i=$start; $i<=$total; $i++){
										
										if(($i)!=$current_page){
									?>
										<a href="<?php echo site_url("user/activity/".$user['id']."?page=".($i-1)."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons"><?php echo $i; ?></a>
									<?php
								 } else {
									 echo "&nbsp;".$i."&nbsp;";
									 }
									
									}
									
									
							
							?>
							
							<?php if($next_page): ?>
							<a href="<?php echo site_url("user/activity/".$user['id']."?page=".$next_page_num."&".$query_string_pagination); ?>" class="form-button small-button pagination-buttons">Next</a>
							<?php endif; ?>
						</div>
						
	</div>

</div>


</div>
