<div class="box-width">
	<div  class="form-container">
		
<div id='create-form'>
<h1 class='h1-title'>Create User</h1>
<div class="form-div">
	
	<div class="validation-errors"><?php echo validation_errors(); ?></div>
	<form action="<?php echo site_url("user/create"); ?>" method='POST' enctype="multipart/form-data" name="create_form" id="create-form-id">
		
		<div class="form-block">
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Full Name</label>
					<input type="text" class="form-input" name="full_name" placeholder="Full Name" value="<?php echo set_value('full_name'); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Mobile Number</label>
					<input type="text" class="form-input" name="mobile" placeholder="Mobile Number" value="<?php echo set_value('mobile'); ?>" minlength='10' maxlength='10' required/>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Email</label>
					<input type="email" class="form-input" name="email" placeholder="Email" value="<?php echo set_value('email'); ?>" minlength='5' maxlength='100' required/>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Record Status</label>
					<label class="form-radio">
					<input type="radio" name="status" value="1" <?php echo set_radio('status',1); ?> required/> Active
					</label>
					<label class="form-radio">
					<input type="radio" name="status" value="0" <?php echo set_radio('status',0); ?> required/> Inactive
					</label>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row blocks-right">
					<input type="submit" class="form-button bg-green" name="submit" value="Submit" />
					<button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("user/browse"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				<div class="clear"></div>
			</div>
		</div>
	</form>
	<script>
	$("#create-form-id").validate({
		rules: {
			/*repassword: {
				equalTo:'#user-password'
			}*/
		}
	});
	</script>
	</div>
</div>


	</div>
</div>
