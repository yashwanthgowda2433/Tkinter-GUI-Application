<div class="box-width">
	<div  class="form-container">
		
<div id='edit-form'>
<h1 class='h1-title'>Edit User Info</h1>
<div class="form-div">
	
	<div class="validation-errors"><?php echo validation_errors(); ?></div>
	<form action="<?php echo site_url("user/edit/".$user['User_id']); ?>" method='POST' enctype="multipart/form-data" name="edit_form" id="edit-form-id">
		<input type="hidden" name="User_id" value="<?php echo $user['User_id']; ?>" />
		<div class="form-block">
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">First Name</label>
					<input type="text" class="form-input" name="First_name" placeholder="First Name" value="<?php echo set_value('First_name',$user['First_name']); ?>" required/>
				</div>
				<div class="form-column">
					<label class="radio-label">Last Name</label>
					<input type="text" class="form-input" name="Last_name" placeholder="Last Name" value="<?php echo set_value('Last_name',$user['Last_name']); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Mobile Number</label>
					<input type="text" class="form-input" name="Mobile_number" placeholder="Mobile Number" value="<?php echo set_value('Mobile_number',$user['Mobile_number']); ?>" minlength='10' maxlength='10' required/>
				</div>
				<div class="form-column">
					<label class="radio-label">Email</label>
					<input type="email" class="form-input" name="User_email" placeholder="Email" value="<?php echo set_value('User_email',$user['User_email']); ?>" minlength='5' maxlength='100' required/>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">Password</label>
					<input type="password" class="form-input" id="user-password" name="Password" value="<?php echo set_value('Password'); ?>" minlength='5' maxlength='20' />
				</div>
				<div class="form-column">
					<label class="radio-label">Re-enter Password</label>
					<input type="password" class="form-input" name="Repassword" value="<?php echo set_value('Repassword'); ?>" minlength='5' maxlength='20' />
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column">
					<label class="radio-label">User</label>
					<input type="text" class="form-input" name="User_name" placeholder="UserName" value="<?php echo set_value('User_name',$user['User_name']); ?>" required/>
				</div>
				<div class="form-column">
					<label class="radio-label">Record Status</label>
					<label class="form-radio">
					<input type="radio" name="Status" value="1" <?php echo set_radio('Status',1,$user['Status']==1? true:false); ?> required/> Active
					</label>
					<label class="form-radio">
					<input type="radio" name="Status" value="0" <?php echo set_radio('Status',0,$user['Status']==0? true:false); ?> required/> Inactive
					</label>
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row blocks-right">
					<input type="submit" class="form-button bg-green" name="submit" value="Save.." />
					<button type="button" class="form-button bg-grey" name="submit" onclick="window.location.replace('<?php echo site_url("user/browse"); ?>');"><i class="fas fa-arrow-left"></i> Go Back</button>
					
				<div class="clear"></div>
			</div>
		</div>
	</form>
	<script>
	$("#edit-form-id").validate({
		rules: {
			Repassword: {
				equalTo:'#user-password'
			}
		}
	});
	</script>
	</div>
</div>


	</div>
</div>
