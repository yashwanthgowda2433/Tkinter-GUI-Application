<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'><?php echo $user['firstname']." ".$user['lastname']; ?></h1>
	<div class="subscription-nav">
		<?php
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				$current_nav=$class."/".$method;
		?>
		<a <?php if($current_nav=="user/view"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/view/".$user['id']); ?>">Profile</a>
		<a <?php if($current_nav=="user/subscriptions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/subscriptions/".$user['id']); ?>">Subscription</a>
		<a <?php if($current_nav=="user/transactions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/transactions/".$user['id']); ?>">Transactions</a>
		<a <?php if($current_nav=="user/activity"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/activity/".$user['id']); ?>">Activity Log</a>
		<a <?php if($current_nav=="user/parent_profile"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/parent_profile/".$user['id']); ?>">Parent Profile</a>
		
	</div>
	<div class="clear"></div>
</div>

<div class="module-content-section">
	
	<div class="table-container">
		<form action="<?php echo site_url("user/parent_profile/".$user['id']); ?>" method='POST' enctype="multipart/form-data" name="login_form" id="login-form-id">
		
		<input type="hidden" name="parent_id" value="<?php echo $user['parent_id']; ?>" />
		<div class="form-block">
			
			<div class="form-row">
				<div class="form-column">
					<label>Your First Name <span class="req">*</span></label>
					<input type="text" class="form-input" name="firstname" minlength='4' maxlength='40' placeholder="First Name" value="<?php echo set_value('first_name',$parent['firstname']); ?>" required/>
				</div>
				<div class="form-column">
					<label>Your Last Name <span class="req">*</span></label>
					<input type="text" class="form-input" name="lastname" minlength='1' maxlength='40' placeholder="Last Name" value="<?php echo set_value('last_name',$parent['lastname']); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column">
					<label>Your Email <span class="req">*</span></label>
					<input type="email" class="form-input" name="email" placeholder="Email address" minlength='4' maxlength='50' value="<?php echo set_value('email',$parent['email']); ?>" required/>
				</div>
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column">
					<label>Set Password</label>
					<input type="password" class="form-input" id="user-password" name="password" minlength='8' maxlength='16' placeholder="Password" />
				</div>
				<div class="form-column">
					<label>Re-Enter Password</label>
					<input type="password" class="form-input" name="repassword" minlength='8' maxlength='16' placeholder="Enter Password Again"/>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
					<input type="submit" class="form-button bg-green" name="submit" value="Update Details" />
					
				<div class="clear"></div>
			</div>
			
		</div>
	</form>
	<script>
		
		
	$.validator.addMethod("pwcheck", function(value) {
   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
       && /[a-z]/.test(value) // has a lowercase letter
       && /[A-Z]/.test(value) // has a uppercase letter
       && /[=!\-@._*]/.test(value) // has a special character letter
       && /\d/.test(value) // has a digit
	});
		
	$("#login-form-id").validate({
		rules: {
			mobile: {
      	number: true
    	},
    
			
			repassword: {
				equalTo:'#user-password'
			}
		}, 
		messages: {
			
			password: {
				pwcheck:"Min 1 Capital letter<br/>1 special character<br/>1 digit required"
			}
		
		}
	});
	</script>			
						
	</div>

</div>


</div>
