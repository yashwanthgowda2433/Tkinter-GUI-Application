<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'><?php echo $user['firstname']." ".$user['lastname']; ?></h1>
	<div class="subscription-nav">
		<?php
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				$current_nav=$class."/".$method;
		?>
		<a <?php if($current_nav=="user/view"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/view/".$user['id']); ?>">Profile</a>
		<a <?php if($current_nav=="user/subscriptions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/subscriptions/".$user['id']); ?>">Subscription</a>
		<a <?php if($current_nav=="user/transactions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/transactions/".$user['id']); ?>">Transactions</a>
		<a <?php if($current_nav=="user/activity"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/activity/".$user['id']); ?>">Activity Log</a>
		<a <?php if($current_nav=="user/parent_profile"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/parent_profile/".$user['id']); ?>">Parent Profile</a>
		
	</div>
	<div class="clear"></div>
</div>

<div class="module-content-section">
	
	<div class="table-container">
		
		<?php if($subscription): ?>
		
		<form  name="edit_form" id="edit-form-id">
		<div class="form-block">
			<div class="form-row">
				<div class="form-column data-column">
					<label class="radio-label"><strong>User Name</strong></label>
					<div><?php echo $user['firstname']." ".$user['lastname']; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Plan Name</strong></label>
					<div><?php echo $user_sub['plan_name']; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Stripe Subscription ID</strong></label>
					<div><?php echo $user_sub['paypal_subscription_id']; ?></div>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column data-column">
					<label class="radio-label"><strong>Plan ID</strong></label>
					<div><?php echo $user_sub['paypal_plan_id']; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Billing Interval (Months)</strong></label>
					<div><?php echo $user_sub['billing_interval']; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Price (GBP)</strong></label>
					<div><?php echo $user_sub['price']; ?></div>
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				
				<div class="form-column data-column">
					<label class="radio-label"><strong>Created on</strong></label>
					<div><?php echo date('d-m-Y H:i:s',@$subscription->created); ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Status</strong></label>
					<div><?php echo @$subscription->status; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Started on</strong></label>
					<div><?php echo date('d-m-Y H:i:s',@$subscription->start_date); ?></div>
				</div>
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column data-column">
					<label class="radio-label"><strong>Collection Method</strong></label>
					<div><?php echo @$subscription->collection_method; ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Next Billing Time</strong></label>
					<div><?php echo date('d-m-Y H:i:s',@$subscription->current_period_end); ?></div>
				</div>
				<div class="form-column data-column">
					<label class="radio-label"><strong>Cancelled at</strong></label>
					<div><?php if(@$subscription->status=='canceled'): echo date('d-m-Y H:i:s',@$subscription->canceled_at); else: echo "N/a"; endif; ?></div>
				</div>
				
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				<div class="form-column data-column">
					<label class="radio-label"><strong>Cancellation Requested by User?</strong></label>
					<div><?php echo $user_sub['cancellation_requested']; ?></div>
				</div>
				
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row blocks-right">
				
				<?php if(@$subscription->status!="canceled"): ?>
				
				
				<?php if($user_sub['cancellation_requested']=="yes"): ?>
				
				
				<button type="button" class="form-button small-button bg-grey" name="submit" onclick="confirm_cancellation('<?php echo site_url("user/cancel_sub/".$user_sub['paypal_subscription_id']."/".$user_sub['id']."/".$user['id']); ?>');">Approve Cancellation Request</button>
				
				
				<?php else: ?>
				
				<button type="button" class="form-button small-button bg-grey" name="submit" onclick="confirm_cancellation('<?php echo site_url("user/cancel_sub/".$user_sub['paypal_subscription_id']."/".$user_sub['id']."/".$user['id']); ?>');">Cancel Subscription</button>
				
				
				<?php endif; ?>
				
				<?php endif; ?>
					
					
					
				<div class="clear"></div>
			</div>
			
		</div>
	</form>
	<script>
	$("#edit-form-id").validate({
		rules: {
			/*repassword: {
				equalTo:'#user-password'
			}*/
		}
	});
	
	
	function confirm_cancellation(url){
		var response=confirm("Are you sure you want to cancel this subscription?");
		
		if(response==true){
			
			window.location.href=url;
		
		}
	}
	
	</script>	
	
	<?php else: ?>		
	
	No active Subscription	
			<?php endif; ?>					
	</div>

</div>


</div>
