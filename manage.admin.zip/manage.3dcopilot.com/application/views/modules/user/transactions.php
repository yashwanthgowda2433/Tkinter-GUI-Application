<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'><?php echo $user['firstname']." ".$user['lastname']; ?></h1>
	<div class="subscription-nav">
		<?php
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				$current_nav=$class."/".$method;
		?>
		<a <?php if($current_nav=="user/view"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/view/".$user['id']); ?>">Profile</a>
		<a <?php if($current_nav=="user/subscriptions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/subscriptions/".$user['id']); ?>">Subscription</a>
		<a <?php if($current_nav=="user/transactions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/transactions/".$user['id']); ?>">Transactions</a>
		<a <?php if($current_nav=="user/activity"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/activity/".$user['id']); ?>">Activity Log</a>
		<a <?php if($current_nav=="user/parent_profile"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/parent_profile/".$user['id']); ?>">Parent Profile</a>
		
	</div>
	<div class="clear"></div>
</div>

<div class="module-content-section">
	
	<div class="table-container">
		<table>
						  <tr>
								<th>ID</th>
								
								<th>Attempt Count</th>
								<th>Attempted</th>
								<th>Created</th>
								
								<th>Next Attempt</th>
								<th>Paid</th>
								<th>Period Start</th>
								<th>Period End</th>
								
								<th>Currency</th>
								<th>Subtotal</th>
								<th>Total</th>
								<th>Status</th>
								<th>Action</th>
								
						  </tr>
						  <?php if(@$txns->data){
							  
							   foreach($txns->data as $t): ?>
							<tr>
								<td><?php echo $t->id; ?></td>
								
								<td><?php echo $t->attempt_count; ?></td>
								<td><?php echo $t->attempted; ?></td>
								
								<td><?php echo date('d-m-Y H:i:s',$t->created); ?></td>
								
								<td><?php if($t->paid==1){ echo 'n/a'; } else { echo date('d-m-Y H:i:s',$t->next_payment_attempt); } ?></td>
								<td><?php echo $t->paid; ?></td>
								<td><?php echo date('d-m-Y H:i:s',$t->period_start); ?></td>
								<td><?php echo date('d-m-Y H:i:s',$t->period_end); ?></td>
								
								<td><?php echo $t->currency; ?></td>
								<td><?php echo $t->subtotal; ?></td>
								<td><?php echo $t->total; ?></td>
								<td><?php echo $t->status; ?></td>
								<td>
									<a target="_blank" class="form-button micro-button" href="<?php echo $t->hosted_invoice_url; ?>">View</a>
									
									<?php if(!$this->user_model->check_refunded($t->id)): ?>
									<a target="_blank" class="form-button micro-button" onclick="confirm_refund('<?php echo site_url("user/request_refund/".$t->id."/".$user['id']); ?>');">Refund</a>
									<?php else: ?>
									<span style="    background: #fff99b;
    font-size: 12px;
    display: inline-block;
    padding: 0px 5px;
    border-radius: 4px;
    border: 1px solid #ccc;">Refunded</span>
									<?php endif; ?>
									
								</td>
							</tr>
						  <?php endforeach; 
						  
					  } else {
						  
						  ?>
						  <tr/><td colspan="13">No Transactions</td></tr>
						  <?php } ?>
						  </table>				
						
	</div>

</div>


</div>
<script>

function confirm_refund(url){
		
		
     var response=confirm("Are you sure you want to initiate refund?");
     
     if(response==true){
		 
	   window.location.href=url;
	 
	 }
    
 }

</script>
