<div class="module-block">
<div class="module-title-section">
	
	<h1 class='module-title'><?php echo $user['firstname']." ".$user['lastname']; ?></h1>
	<div class="subscription-nav">
		<?php
				$class=$this->router->fetch_class();
				$method=$this->router->fetch_method();
				$current_nav=$class."/".$method;
		?>
		<a <?php if($current_nav=="user/view"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/view/".$user['id']); ?>">Profile</a>
		<a <?php if($current_nav=="user/subscriptions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/subscriptions/".$user['id']); ?>">Subscription</a>
		<a <?php if($current_nav=="user/transactions"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/transactions/".$user['id']); ?>">Transactions</a>
		<a <?php if($current_nav=="user/activity"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/activity/".$user['id']); ?>">Activity Log</a>
		<a <?php if($current_nav=="user/parent_profile"): echo "class='active-nav-tab'"; endif; ?> href="<?php echo site_url("user/parent_profile/".$user['id']); ?>">Parent Profile</a>
		
	</div>
	<div class="clear"></div>
</div>

<div class="module-content-section">
	
	<div class="table-container">
		
		<div class="form-block user-info-block" style="padding:25px; padding-bottom:0px; font-size:11px;">
			
			<h2 style="margin-top:0px; padding-bottom:20px;">
				<?php if(!isset($user_sub)){ ?>
					<i class="fa fa-times-circle" style="font-size:1.3em; position:relative; top:2px; color:#ffa5a5;" title='Inactive'></i>
					<?php } else if($user_sub['status']=='active'){ ?>
					<i class="fa fa-play-circle" style=" font-size:1.3em; position:relative; top:2px; color:#9c3;" title='Active'></i>
					<?php } else if($user_sub['status']=='cancelled'){ ?>
					<i class="fa fa-stop" style=" font-size:1.2em; position:relative; top:1px; color:#c00;"></i> 
					<?php } ?> 
					Member Details for 
					<?php echo $user['firstname']." ".$user['lastname'];  if(isset($user_sub['total_days'])){?> <span style="display: inline-block;
    padding: 6px;
    border-radius: 5px;
    background: #FFFAAB;
    border: 1px solid #f1ed5e;"><?php echo @$user_sub['total_days']; ?> Days</span>
					<?php } ?>
			</h2>
			
			<div class="form-row" style="background: #f5f5f5; padding: 10px;">
				<div class="form-column" style="width:130px;">
					Membership Status:
				</div>
				<div class="form-column">
					
					<?php if(!isset($user_sub)){ ?>
					<i class="fa fa-times-circle" style="font-size:1.3em; position:relative; top:2px; color:#ffa5a5;" title='Inactive'></i> Not Subscribed
					<?php } else if($user_sub['status']=='active'){ ?>
					<i class="fa fa-play-circle" style=" font-size:1.3em; position:relative; top:2px; color:#9c3;" title='Active'></i> Subscription became active on <?php echo date("M d, Y h:i a",strtotime($user_sub['created'])); ?>
					<?php } else if($user_sub['status']=='cancelled'){ ?>
					<i class="fa fa-stop" style=" font-size:1.2em; position:relative; top:1px; color:#c00;"></i> Subscription was cancelled on <?php echo date("M d, Y h:i a",strtotime($user_sub['last_updated'])); ?>
					<?php } ?>
					
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row" style="padding:10px;">
				<div class="form-column" style="width:130px;">
					Account Stats:
				</div>
				<div class="form-column">
					
					<i class="fa fa-info mm-icon black" style=" font-size:1.2em; position:relative; top:1px; padding-left:4px; margin-right:4px; color:#222;"></i> Member ID is <?php echo $user['id']; ?><br/>
					<i class="far fa-calendar-alt" style=" font-size:1.2em; position:relative; top:1px; color:#AE6CC8;"></i> Account created on <?php echo date("M d, Y h:i a",strtotime($user['created'])); ?>
					
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row" style="background: #f5f5f5; padding: 10px;">
				<div class="form-column" style="width:130px;">
					Engagement Stats:
				</div>
				<div class="form-column">
					
					<i class="far fa-calendar-alt" style=" font-size:1.2em; position:relative; top:1px; color:#AE6CC8;"></i> Last Login date: <?php if($activity_data){ echo date("M d, Y h:i a",strtotime($activity_data['created'])); } ?><br/>
					<i class="fas fa-globe" style=" font-size:1.2em; position:relative; top:1px; color:#AE6CC8;"></i> Last Login IP: <?php if($activity_data){ echo $activity_data['ip_address']; } ?><br/>
					<i class="fa fa-key" style=" font-size:1.2em; position:relative; top:1px; color:#F6B91B;"></i> Logins: 1<br/>
					
				</div>
				<div class="clear"></div>
			</div>
			<div class="form-row" style="padding:10px;">
				<div class="form-column" style="width:130px;">
					Tools:
				</div>
				<div class="form-column">
					
					
					<!--<i class="fa fa-key" style=" font-size:1.2em; position:relative; top:1px; color:#AE6CC8;"></i> Login as this member<br/>-->
					<i class="fas fa-paper-plane" style=" font-size:1.2em; position:relative; top:1px; color:#F6B91B;"></i> <a href="#" onclick="confirm_resend_mail('<?php echo site_url("user/resend_welcome_email/".$user['id']); ?>')">Resend Welcome Email</a><br/>
					<i class="fa fa-eraser" style=" font-size:1.2em; position:relative; top:1px; color:#F6B91B;"></i> <a href="#" onclick="confirm_delete('<?php echo site_url("user/soft_delete/".$user['id']); ?>')">Forget this user</a><br/>
					
				</div>
				<div class="clear"></div>
			</div>
		</div>
		
		<form action="<?php echo site_url("user/view/".$user['id']); ?>" method='POST' enctype="multipart/form-data" name="login_form" id="login-form-id">
		<div style="background: #f5f5f5; padding: 20px;">
		<input type="hidden" name="user_id" value="<?php echo $user['id']; ?>" />
		<h3>Update Info</h3>
		<div class="form-block">
			
			<div class="form-row">
				<div class="form-column">
					<label>First Name <span class="req">*</span></label>
					<input type="text" class="form-input" name="firstname" minlength='4' maxlength='40' placeholder="First Name" value="<?php echo set_value('first_name',$user['firstname']); ?>" required/>
				</div>
				<div class="form-column">
					<label>Last Name <span class="req">*</span></label>
					<input type="text" class="form-input" name="lastname" minlength='1' maxlength='40' placeholder="Last Name" value="<?php echo set_value('last_name',$user['lastname']); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			
			
			<div class="form-row">
				<div class="form-column">
					<label>Username <span class="req">*</span></label>
					<input type="text" class="form-input" name="username" minlength='5' maxlength='15' placeholder="Username" value="<?php echo set_value('username',$user['username']); ?>" required/>
				</div>
				<div class="form-column">
					<label>Date of Birth <span class="req">*</span></label>
					<input type="date" class="form-input" name="dob" placeholder="Date of Birth" value="<?php echo set_value('dob',$user['dob']); ?>" required/>
				</div>
				<div class="clear"></div>
			</div>
			
			
			
			<div class="form-row">
				<div class="form-column">
					<label>Set Password</label>
					<input type="password" class="form-input" id="user-password" name="password" minlength='8' maxlength='16' placeholder="Password" />
				</div>
				<div class="form-column">
					<label>Re-Enter Password</label>
					<input type="password" class="form-input" name="repassword" minlength='8' maxlength='16' placeholder="Enter Password Again" />
				</div>
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
				
				<div class="clear"></div>
			</div>
			
			<div class="form-row">
					<input type="submit" class="form-button bg-green" name="submit" value="Update Details" />
					
					
				<div class="clear"></div>
			</div>
			
		</div>
		</div>
	</form>
	<script>
		
	$.validator.addMethod("pwcheck", function(value) {
   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
       && /[a-z]/.test(value) // has a lowercase letter
       && /[A-Z]/.test(value) // has a uppercase letter
       && /[=!\-@._*]/.test(value) // has a special character letter
       && /\d/.test(value) // has a digit
	});	
		
	$("#login-form-id").validate({
		rules: {
			mobile: {
      	number: true
    	},
    	
    	
		repassword: {
			equalTo:'#user-password'
		}
	  }, 
		messages: {
			
			password: {
				pwcheck:"Min 1 Capital letter<br/>1 special character<br/>1 digit required"
			}
		
		}
	});
	</script>	
	
	<script>

function confirm_delete(url){
		
		
     var response=confirm("Are you sure you want to forget this member?\n\nAny active subscriptions will be cancelled, and user information will be immediately be anonymized if you proceed.");
     
     if(response==true){
		 
	   window.location.href=url;
	 
	 }
    
 }
 
 function confirm_resend_mail(url){
		
		
     var response=confirm("Are you sure you want to resend welcome email?");
     
     if(response==true){
		 
	   window.location.href=url;
	 
	 }
    
 }

</script>		
						
	</div>

</div>


</div>
