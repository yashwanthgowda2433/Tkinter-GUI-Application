<?php

define('DB_DEBUG', TRUE);

define('DB_HOST_NAME_WRITE', 'localhost');
define('DB_USER_NAME_WRITE', 'user');
define('DB_PASS_NAME_WRITE', 'Muruli143@');
define('DB_NAME_WRITE', '3dpilot');

define('DB_HOST_NAME_READ', 'localhost');
define('DB_USER_NAME_READ', 'user');
define('DB_PASS_NAME_READ', 'Muruli143@');
define('DB_NAME_READ',	'3dpilot');

?>
